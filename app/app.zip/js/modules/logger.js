export default function logger() {
    console.log('Hello world');
}
